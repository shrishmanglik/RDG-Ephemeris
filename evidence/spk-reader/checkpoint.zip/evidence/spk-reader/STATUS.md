# Binary reader checkpoint

Owner: Codex chat 01a17381-8eb1-73e0-86ce-b39e8680dbfc, Track A ephemeris-oss.
Date: 2026-10-26. Base: 2bc89be35dac39c38f0ec189acc83a1a4918b369.
Workspace: C:/AGI/worktrees/ephemeris-oss-staging/chebyshev-reader-20261026.
Branch: codex/chebyshev-reader-20261026. No commit/push/PR at this checkpoint.

The originally named specification and Astro worktree were absent. The recovered
master specification is the estate's
command-centre/war-room/chief-of-staff/specs/2026-10-25-march-2027-offline-super-apps-and-mds-mass-production/SPEC.md,
section 9.2. The gap matrix was reconciled against existing source before
continuing. This is an increment of the existing engine, not a parallel engine.

Collision boundary: only this engine checkout is edited. The separate
ephemeris-gurukul-compat checkout owns the Swiss-signature adapter. Astro-AI-Studio,
Gurukul UI, pricing, sidecar, case data and media remain with their named owners.
The coordination ownership table dated 2026-10-25 section 2b was read back.

Configured model: gpt-6.1-sol, model_reasoning_effort high, read from selected
configuration fields. Requested Ultra override has no verifiable in-flight
readback in this turn. Do not claim that it took effect.

Bound: zero added spend, no paid compute or model/API inference; no Swiss source;
two failed attempts with the same signature require a changed approach. Normal
memory/admission gates apply; no priority or threshold overrides. No public
release, publishing, credentials, provider mutation or payments. A draft PR
requires green relevant checks; broader physical accuracy remains a separate gate.

Independent review identified reserved-record addressing, inconsistent record
normalization and unnecessary evaluation above a common ancestor. All three have
failing-before regressions and repaired Rust tests. Latest Rust run: 5 unit and
11 reader integration tests passed. Disabling the frame detector made its actual
regression fail; restored Rust tests passed. Review of the repairs found no
remaining concrete defect; that is draft feedback, not release approval.

Fresh native/WASM build after the common-ancestor fix is recorded in
rebuild-after-relative.txt. Math-only module remains 63,184 bytes; optional reader
82,468 bytes. Native SHA-256:
472d4aad6710c068a2bfdbe7fd569229dad6761610b12d2a59f1ef0224f6fea7.

The full Python 3.13 suite ran: 854 passed, 1 failed, 4 skipped. The failure was
provenance scanning of the internal comparison/ownership matrix in public docs.
That matrix was moved to this internal evidence folder and the public design
note now uses neutral wording. No scanner, exception list or test was weakened.
The full rerun, Python 3.11 run, package checks and exact-head CI remain pending.

Both DE441 files were downloaded with the existing streaming fetcher and verified
against the pinned hashes. jpl-reader-qualification.json records 714 sampled
same-kernel states over DE440 and both DE441 parts, including the published data
endpoints. It binds the preceding native binary f6c2ff3b..., not the final
common-ancestor repair, and must be regenerated for final qualification.
The DE440-only JSON's older hard-coded "asset absent" label is erroneous metadata;
preserved raw bytes are superseded by the verified fetch receipt and this note.
The test metadata has been corrected without rewriting its historical receipts.

Whole-repository export self-test controls passed but the scan found eight
inherited machine-path disclosures in old tracked evidence. No secret value was
printed. Public whole-repository export remains blocked; no public release is
authorized. This does not qualify or disqualify the separately bounded package.

Memory repeatedly crossed below 2,048 MiB; normal admission and physical-memory
checks are recorded separately. Unused slots were released. Cache reclamation
was executed twice when C: exceeded 88 percent and found zero eligible candidates.
No unrelated application or other owner's build was terminated.
