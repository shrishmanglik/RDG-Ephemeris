# Seekable JPL SPK reader

Decision, 2026-10-26. Extend the existing Rust core rather than replacing the
Python engine or copying the active compatibility-shim work. Base: 2bc89be.

The input contract is `SpkKernel::open(reader: impl Read + Seek)`. The caller
retains responsibility for asset identity using the existing kernel registry.
`state(target, center, tdb_seconds)` returns geometric J2000 position in km and
velocity in km/s. Epoch is TDB seconds since J2000, not TT, UT1 or UTC. The reader
hides DAF byte order, linked summaries, one-based word addressing, segment
priority, center paths, record selection and analytic polynomial derivatives.
It reads one record at a time. Native DE441 access does not allocate the whole
kernel. No new dependency or network call is introduced.

Python exposes the opt-in `rust_bridge.read_spk_state()` with an explicit native
library path. JavaScript/TypeScript exposes `readSpkState()` after loading the
reader-enabled WebAssembly artifact. The browser copies caller-supplied bytes
into a temporary WASM allocation and releases it in `finally`; output is copied
before that allocation is freed. A multi-gigabyte DE441 browser allocation may
be refused. Neither SDK silently falls back to approximate coordinates.

The old math-only `ephemeris_core.wasm` retains its existing 64 KiB gate. The
optional `spk-reader` feature produces `ephemeris_spk.wasm`, containing the same
math plus the binary reader and allocator. Ordinary and size-optimized combined
builds exceeded the old budget; raising that budget was rejected. Keeping the
optional file separate preserves the lightweight path. Both modules execute
the same existing Clenshaw implementation, not parallel numerical engines.

Supported: IEEE little/big-endian DAF/SPK, Type 2 position polynomials with
analytic velocity, Type 3 position/velocity polynomials, J2000 frame, inclusive
segment endpoints, later-segment priority and connected center paths. Invalid
directories, cycles, missing coverage, unsupported selected frames/types and
nonfinite data fail explicitly. A selected unsupported segment cannot fall back
to an earlier one. Record allocations are capped at 65,536 double words.

This primitive does not apply light-time, relativistic apparent-place effects,
topocentric observer correction, atmospheric refraction or civil-time models.
The existing engine owns those operations. Numerical agreement with another
reader of the same kernel is not physical prediction accuracy or apparent-place
agreement with Horizons. In particular it cannot remove DE440/DE441 model
differences in the existing lunar benchmark.

Build declared inputs before testing:

```sh
rustup target add wasm32-unknown-unknown
python tools/build_rust_inputs.py
cargo test --manifest-path rust/ephemeris-core/Cargo.toml
pytest -q tests/test_spk_reader.py tests/test_rust_crate_parity.py
```

The repository CI definition runs this preparation before Python tests. Node.js
is required for actual WASM execution. The Python wheel remains pure Python:
native libraries and browser assets are optional repository builds, not bundled
platform binaries. This increment does not claim a released binary distribution.

Tests use independently written polynomial fixtures in both byte orders, actual
native file calls, actual WASM execution, malformed/unsupported controls and
the installed MIT-licensed jplephem reader as a numerical comparator. Real
kernel hashes and raw sampled errors belong in the task evidence.

Primary format references, consulted 2026-10-26:

- [NAIF DAF Required Reading](https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/req/daf.html)
- [NAIF SPK Required Reading, Types 2 and 3](https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/req/spk.html)
- [JPL DE440/DE441 coverage](https://ssd.jpl.nasa.gov/planets/eph_export.html)

Only public format/theory documentation and independently generated test data
were used; no competing implementation source was read or copied.
